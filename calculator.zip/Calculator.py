import tkinter as tk
from tkinter import ttk

class Calculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Calculator")
        self.root.geometry("400x600")
        self.root.configure(bg="black")

        self.expression = ""
        self.text_input = tk.StringVar()

        self.create_widgets()

    def create_widgets(self):
        entry = ttk.Entry(self.root, textvariable=self.text_input, font=('arial', 20, 'bold'), justify='right', state='readonly')
        entry.grid(row=0, column=0, columnspan=4, pady=20)
        
        buttons = [
            ('AC', 1, 0), ('(', 1, 1), (')', 1, 2), ('/', 1, 3),
            ('7', 2, 0), ('8', 2, 1), ('9', 2, 2), ('*', 2, 3),
            ('4', 3, 0), ('5', 3, 1), ('6', 3, 2), ('-', 3, 3),
            ('1', 4, 0), ('2', 4, 1), ('3', 4, 2), ('+', 4, 3),
            ('0', 5, 0), ('.', 5, 1), ('=', 5, 2)
        ]

        for (text, row, column) in buttons:
            if text == '=':
                button = tk.Button(self.root, text=text, font=('arial', 20, 'bold'), fg="green", bg="red", command=self.calculate)
            elif text == 'AC':
                button = tk.Button(self.root, text=text, font=('arial', 20, 'bold'), fg="green", bg="red", command=self.clear)
            else:
                button = tk.Button(self.root, text=text, font=('arial', 20, 'bold'), fg="green", bg="red", command=lambda t=text: self.append_to_expression(t))
            button.grid(row=row, column=column, sticky='nsew')
        
        self.root.bind('<Key>', self.key_input)

    def append_to_expression(self, value):
        self.expression += str(value)
        self.text_input.set(self.expression)

    def calculate(self):
        try:
            self.expression = self.expression.replace('y', '*y')
            self.expression = str(eval(self.expression))
            self.text_input.set(self.expression)
        except Exception as e:
            self.text_input.set("Error")
            self.expression = ""

    def clear(self):
        self.expression = ""
        self.text_input.set("")

    def key_input(self, event):
        key = event.char
        if key.isdigit() or key in '()+-*/.':
            self.append_to_expression(key)
        elif key == '\r':  
            self.calculate()
        elif key == '\x08': 
            self.expression = self.expression[:-1]
            self.text_input.set(self.expression)

if __name__ == "__main__":
    root = tk.Tk()
    calculator = Calculator(root)
    root.mainloop()




#__  __    _    ____  _____   ______   __  __  __  ___ _____ _____        _____ ____  _ ____  _____ 
#|  \/  |  / \  |  _ \| ____| | __ ) \ / / |  \/  |/ _ \_   _/ _ \ \      / /_ _/ ___|/ |___ \|___ / 
#| |\/| | / _ \ | | | |  _|   |  _ \\ V /  | |\/| | | | || || | | \ \ /\ / / | |\___ \| | __) | |_ \ 
#| |  | |/ ___ \| |_| | |___  | |_) || |   | |  | | |_| || || |_| |\ V  V /  | | ___) | |/ __/ ___) |
#|_|  |_/_/   \_\____/|_____| |____/ |_|   |_|  |_|\___/ |_| \___/  \_/\_/  |___|____/|_|_____|____/ 